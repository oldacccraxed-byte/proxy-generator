Proxy Generator v2 Android project
Features: offline generator up to 100,000 rows per run; sequential/random/unchanged username modes; batch TXT exports; bulk import and duplicate cleanup; format conversion; preview and session history.
No proxy connection testing is included. Data remains local.
Build: Open this folder in Android Studio, sync Gradle, install Android SDK Platform 35 if prompted, then Build > Build APK(s). Debug APK output: app/build/outputs/apk/debug/app-debug.apk.
